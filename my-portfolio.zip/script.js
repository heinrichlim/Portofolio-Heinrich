document.addEventListener("DOMContentLoaded", () => {
    console.log("Dark minimalist portfolio loaded successfully.");

    const footerYear = document.querySelector("footer p");
    if (footerYear) {
        const currentYear = new Date().getFullYear();
        footerYear.innerHTML = `© ${currentYear} Heinrich Spencer Lim. Built for Internship Applications.`;
    }
});
