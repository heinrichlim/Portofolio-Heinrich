# Heinrich Spencer Lim - Portfolio 🚀

> Information Systems Student at BINUS University | Project Manager & Business-Tech Professional

Welcome to my personal portfolio repository! This website showcases my corporate experience, project management background, and technical tool proficiencies for internship opportunities.

## 🛠️ Built With
* **HTML5 & CSS3** 
* **Tailwind CSS** 
* **JavaScript** 
* **Vercel** 

## 📂 Project Structure
```text
my-portfolio/
├── index.html       
├── style.css        
└── script.js        
```

## 📬 Connect With Me
* **LinkedIn:** [Your LinkedIn URL]
* **GitHub:** [Your GitHub URL]
* **Email:** your.email@example.com
